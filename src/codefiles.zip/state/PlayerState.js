import { SKILL_DEFS, EXP_TABLE, MAX_SKILL_LEVEL } from "../data/playerSkillsData.js";

export default class PlayerState {
  constructor() {
    this.inventory = [];
    this.maxSlots = 20;

    this.skills = this.createDefaultSkills();

    this.equipped = {
      weapon: null,
      head: null,
      body: null,
      legs: null,
      feet: null,
      accessory1: null,
      accessory2: null
    };

    this.bonusStats = {
      maxHealth: 0,
      defense: 0,
      attack: 0,
      speed: 0,
      accuracy: 0,
      evasion: 0
    };

    this.currentHealth = 10;
  }

  createDefaultSkills() {
    const skills = {};

    Object.entries(SKILL_DEFS).forEach(([skillId, def]) => {
      skills[skillId] = {
        level: def.startLevel ?? 1,
        exp: def.startExp ?? 0
      };
    });

    return skills;
  }

  // -------------------------
  // INVENTORY
  // -------------------------

  isInventoryFull() {
    return this.inventory.length >= this.maxSlots;
  }

  hasInventorySpace(amount = 1) {
    return this.inventory.length + amount <= this.maxSlots;
  }

  canReceiveItems(items = []) {
    return this.inventory.length + items.length <= this.maxSlots;
  }

  addItem(item) {
    if (!this.hasInventorySpace(1)) {
      return false;
    }

    this.inventory.push(item);
    return true;
  }

  addItems(items = []) {
    if (!this.canReceiveItems(items)) {
      return false;
    }

    this.inventory.push(...items);
    return true;
  }

  removeItem(itemId) {
    const index = this.inventory.findIndex((item) => item.id === itemId);

    if (index === -1) {
      return false;
    }

    this.inventory.splice(index, 1);
    return true;
  }

  hasItem(itemId) {
    return this.inventory.some((item) => item.id === itemId);
  }

  countItem(itemId) {
    return this.inventory.filter((item) => item.id === itemId).length;
  }

  // -------------------------
  // SKILLS
  // -------------------------

  getSkill(skillId) {
    if (!this.skills[skillId]) {
      this.skills[skillId] = { level: 1, exp: 0 };
    }

    return this.skills[skillId];
  }

  getSkillLevel(skillId) {
    return this.getSkill(skillId).level;
  }

  getSkillExp(skillId) {
    return this.getSkill(skillId).exp;
  }

  hasSkillLevel(skillId, requiredLevel) {
    return this.getSkillLevel(skillId) >= requiredLevel;
  }

  getExpNeededForNextLevel(skillId) {
    const skill = this.getSkill(skillId);

    if (skill.level >= MAX_SKILL_LEVEL) {
      return 0;
    }

    return EXP_TABLE[skill.level];
  }

  addSkillExp(skillId, amount) {
    const skill = this.getSkill(skillId);

    if (skill.level >= MAX_SKILL_LEVEL) {
      return {
        leveledUp: false,
        levelsGained: 0,
        level: skill.level,
        exp: skill.exp
      };
    }

    skill.exp += amount;

    let levelsGained = 0;

    while (skill.level < MAX_SKILL_LEVEL) {
      const expNeeded = EXP_TABLE[skill.level];

      if (skill.exp < expNeeded) {
        break;
      }

      skill.exp -= expNeeded;
      skill.level += 1;
      levelsGained += 1;
    }

    if (skill.level >= MAX_SKILL_LEVEL) {
      skill.level = MAX_SKILL_LEVEL;
      skill.exp = 0;
    }

    return {
      leveledUp: levelsGained > 0,
      levelsGained,
      level: skill.level,
      exp: skill.exp
    };
  }

  setSkillLevel(skillId, level) {
    const skill = this.getSkill(skillId);
    skill.level = Math.max(1, Math.min(level, MAX_SKILL_LEVEL));

    if (skill.level >= MAX_SKILL_LEVEL) {
      skill.exp = 0;
    }
  }

  setSkillExp(skillId, exp) {
    const skill = this.getSkill(skillId);
    skill.exp = Math.max(0, exp);
  }

  // -------------------------
  // EQUIPMENT
  // -------------------------

  equip(slot, item) {
    this.equipped[slot] = item;
  }

  unequip(slot) {
    this.equipped[slot] = null;
  }

  getEquipped(slot) {
    return this.equipped[slot] ?? null;
  }

  hasEquipped(slot) {
    return this.getEquipped(slot) !== null;
  }

  getEquipmentStatTotals() {
    const totals = {
      maxHealth: 0,
      defense: 0,
      attack: 0,
      speed: 0,
      accuracy: 0,
      evasion: 0
    };

    Object.values(this.equipped).forEach((item) => {
      if (!item || !item.bonuses) {
        return;
      }

      Object.entries(item.bonuses).forEach(([statId, value]) => {
        totals[statId] = (totals[statId] ?? 0) + value;
      });
    });

    return totals;
  }

  // -------------------------
  // DERIVED STATS
  // -------------------------

  getStats() {
    const vigor = this.getSkillLevel("vigor");
    const endurance = this.getSkillLevel("endurance");
    const strength = this.getSkillLevel("strength");
    const agility = this.getSkillLevel("agility");
    const dexterity = this.getSkillLevel("dexterity");

    const equipmentStats = this.getEquipmentStatTotals();

    const maxHealth =
      10 +
      vigor * 2 +
      equipmentStats.maxHealth +
      this.bonusStats.maxHealth;

    const attack =
      1 +
      strength * 2 +
      equipmentStats.attack +
      this.bonusStats.attack;

    const defense =
      1 +
      endurance +
      equipmentStats.defense +
      this.bonusStats.defense;

    const speed =
      15 +
      agility * 0.5 +
      dexterity * 0.5 +
      equipmentStats.speed +
      this.bonusStats.speed;

    const accuracy =
      1 +
      dexterity * 2 +
      equipmentStats.accuracy +
      this.bonusStats.accuracy;

    const evasion =
      1 +
      agility * 2 +
      equipmentStats.evasion +
      this.bonusStats.evasion;

    return {
      health: this.currentHealth,
      maxHealth,
      attack,
      defense,
      speed,
      accuracy,
      evasion
    };
  }

  // -------------------------
  // HEALTH
  // -------------------------

  setCurrentHealth(value) {
    const stats = this.getStats();
    this.currentHealth = Math.max(0, Math.min(value, stats.maxHealth));
  }

  heal(amount) {
    this.setCurrentHealth(this.currentHealth + amount);
  }

  takeDamage(amount) {
    this.setCurrentHealth(this.currentHealth - amount);
  }

  isDead() {
    return this.currentHealth <= 0;
  }

  restoreToFullHealth() {
    this.currentHealth = this.getStats().maxHealth;
  }

  // -------------------------
  // BONUS STATS
  // -------------------------

  setBonusStat(statId, value) {
    this.bonusStats[statId] = value;
  }

  addBonusStat(statId, value) {
    this.bonusStats[statId] = (this.bonusStats[statId] ?? 0) + value;
  }

  clearBonusStats() {
    this.bonusStats = {
      maxHealth: 0,
      defense: 0,
      attack: 0,
      speed: 0,
      accuracy: 0,
      evasion: 0
    };

    this.setCurrentHealth(this.currentHealth);
  }
}