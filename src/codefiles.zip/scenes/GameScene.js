import Phaser from "phaser";
import Player from "../ui/PlayerPanel.js";
import GamePanel from "../ui/GamePanel.js";
import CursorManager from "../systems/CursorManager.js";
import CombatSystem from "../systems/CombatSystem.js";
import BattlePanel from "../ui/BattlePanel.js";
import PlayerState from "../state/PlayerState.js";
import PlayerWorldState from "../state/PlayerWorldState";
import MapUI from "../ui/MapUI";
import { TEST_MAP_DATA } from "../data/mapData.js";
import { ENEMY_DATA } from "../data/enemiesData.js";
import { MAP_MUSIC } from "../data/musicData.js"; 
import MusicManager from "../systems/musicManager.js";
import InventorySystem from "../systems/InventorySystem.js";
import InventoryPanel from "../ui/InventoryPanel.js";
import LootSystem from "../systems/LootSystem.js";
import LootPanel from "../ui/LootPanel.js";
import ActivitySystem from "../systems/ActivitySystem.js";
import GatheringSystem from "../systems/GatherSystem.js";
import GatherProgressUI from "../ui/GatherProgressUI.js";
import ProcessPanel from "../ui/ProcessPanel.js";
import ProcessingSystem from "../systems/ProcessingSystem.js";
import NodeInteractionSystem from "../systems/NodeInteractionSystem.js";
import EventBus from "../core/EventBus.js";
import GameplayRequestRouter from "../systems/GameplayRequestRouter.js";

export default class GameScene extends Phaser.Scene {
  constructor() {
    super("GameScene");

    this.layout = {
      playerPanelX: 152,
      playerPanelY: 575,
      battlePanelX: 527,
      battlePanelY: 575
    }
  }

  create() {
    this.eventBus = new EventBus();

    this.nodeInteractionSystem = new NodeInteractionSystem(this.eventBus);
    this.nodeInteractionSystem.register();

    this.input.mouse.disableContextMenu();

    this.cursorManager = new CursorManager(this);
    this.cursorManager.create();

    

    //this.musicManager = new MusicManager(
    //  this,
    //  MAP_MUSIC.map((track) => track.key),
    //  {volume: 0.4}
    //);
    
    //this.musicManager.start();

    this.playerPanel = new Player(this, this.layout.playerPanelX, this.layout.playerPanelY);

    

    this.playerState = new PlayerState();
    this.playerWorldState = new PlayerWorldState();

    this.battlePanel = new BattlePanel(this, this.layout.battlePanelX, this.layout.battlePanelY);
    this.battlePanel.hide();

    this.mapUI = new MapUI(this, 20, 20, TEST_MAP_DATA, this.playerWorldState, this.eventBus);

    this.combatSystem = new CombatSystem(this, {
      battlePanel: this.battlePanel,
      playerPanel: this.playerPanel,
      playerState: this.playerState,
      playerWorldState: this.playerWorldState,
      mapUI: this.mapUI
    });

    this.inventorySystem = new InventorySystem(this.playerState);
    
    this.inventoryPanel = new InventoryPanel(
      this,
      820,
      575,
      this.inventorySystem
    );
    this.inventoryPanel.hide();
    //TEST ONLY REMOVE AFTER
    this.inventorySystem.addItem("wolf_pelt", 2);
    this.inventorySystem.addItem("blue_berries", 7);
    this.inventorySystem.addItem("copper_ore", 50);
    this.inventorySystem.addItem("oak_log", 50);

    this.lootSystem = new LootSystem();
    this.lootPanel = new LootPanel(
      this,
      600,
      575,
      this.lootSystem,
      this.inventorySystem,
      this.inventoryPanel
    );

    this.gamePanel = new GamePanel(this, 1000, 10, {
      onCharacterClick: () => {
        this.playerPanel.show();
      },
      onInventoryClick: () => {
        this.inventoryPanel.show();
      },
      onSkillsClick: () => {
        this.playerPanel.setState("idle");
      }
    });

    this.activitySystem = new ActivitySystem(this);

    this.gatherProgressUI = new GatherProgressUI(this);

    this.gatheringSystem = new GatheringSystem(this, {
      playerState: this.playerState,
      playerWorldState: this.playerWorldState,
      inventorySystem: this.inventorySystem,
      activitySystem: this.activitySystem,
      mapUI: this.mapUI,
      gatherProgressUI: this.gatherProgressUI
    });
    //TEST FOR GATHER NODE
    this.playerState.setSkillLevel("mining", 20);

    this.processPanel = new ProcessPanel(this, 930, 520, null);
    this.processPanel.hide();

    this.processingSystem = new ProcessingSystem(this, {
      playerState: this.playerState,
      playerWorldState: this.playerWorldState,
      inventorySystem: this.inventorySystem,
      activitySystem: this.activitySystem,
      mapUI: this.mapUI,
      processPanel: this.processPanel
    });
    //wire back to processpanel
    this.processPanel.processingSystem = this.processingSystem;


    this.gameplayRequestRouter = new GameplayRequestRouter(this.eventBus, {
      mapUI: this.mapUI,
      combatSystem: this.combatSystem,
      gatheringSystem: this.gatheringSystem,
      processingSystem: this.processingSystem
    });

    this.gameplayRequestRouter.register();

    this.events.on("shutdown", () => {
      if (this.musicManager) {
        this.musicManager.destroy();
        this.musicManager = null;
      }
    });

  }



  handleEnemyNodeClick(nodeData, node, mapUI) {
    const enemyId = this.getEnemyIdFromNode(nodeData);

    if (!enemyId) {
      console.warn("No enemyId found for node:", nodeData.id);
      return;
    }

    const enemyData = ENEMY_DATA[enemyId];

    if (!enemyData) {
      console.warn("Enemy data not found for:", enemyId);
      return;
    }

    this.combatSystem.startBattle({
      enemyId,
      enemyData,
      nodeData,
      node
    });
  }

  handleGatherNodeClick(nodeData, node) {
    this.gatheringSystem.startGathering(nodeData, node);
  }

  handleProcessNodeClick(nodeData, node) {
  this.processingSystem.openStation(nodeData, node);
  }

  getEnemyIdFromNode(nodeData) {
    // Temporary v1 mapping:
    // all enemy nodes use gray_wolf
    if (nodeData.type === "enemy") {
      return "gray_wolf";
    }

    return null;
  }

  update(time, delta) {
    if (this.playerPanel) {
    this.playerPanel.update();
    }

    if (this.battlePanel) {
    this.battlePanel.update();
    }
    
    if (this.combatSystem) {
      this.combatSystem.update(delta);
    }

    if (this.activitySystem) {
      this.activitySystem.update(delta);
    }

    if(this.gatherProgressUI) {
      this.gatherProgressUI.update();
    }

    if (this.processingSystem) {
      this.processingSystem.update();
    }

    if(this.eventBus) {
      this.eventBus.process();
    }
    
  }
}