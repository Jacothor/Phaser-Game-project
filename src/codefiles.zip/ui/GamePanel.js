import { addText } from "../utils/addText.js";
const TEXT_COLOR = 0xffffff;

export default class GamePanel {
    constructor(scene, x, y, actions = {}) {
        this.scene = scene;
        this.x = x;
        this.y = y;
        this.actions = actions;

        const PANEL_WIDTH = 270;
        const PANEL_HEIGHT = 692;

        const BUTTON_WIDTH = 100;
        const BUTTON_HEIGHT = 36;
        const BUTTON_GAP = 10;
        const BUTTON_START_X = 160;
        const BUTTON_Y = 300;

        this.container = this.scene.add.container(x, y);

        this.bg = this.scene.add.graphics();
        this.bg.fillStyle(0x090A14, 1);
        this.bg.lineStyle(2, 0x752438, 1);
        this.bg.fillRect(0, 0, PANEL_WIDTH, PANEL_HEIGHT);
        this.bg.strokeRect(0, 0, PANEL_WIDTH, PANEL_HEIGHT);

        this.characterButton = this.createButton(
            BUTTON_START_X,
            BUTTON_Y,
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "Character",
            () => {
                if (this.actions.onCharacterClick) {
                    this.actions.onCharacterClick();
                }
            }
        );

        this.inventoryButton = this.createButton(
            BUTTON_START_X,
            BUTTON_Y + (BUTTON_HEIGHT + BUTTON_GAP),
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "Inventory",
            () => {
                if (this.actions.onInventoryClick) {
                    this.actions.onInventoryClick();
                }
            }
        );

        this.skillsButton = this.createButton(
            BUTTON_START_X ,
            BUTTON_Y + (BUTTON_HEIGHT + BUTTON_GAP) * 2,
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "Skills",
            () => {
                if (this.actions.onSkillsClick) {
                    this.actions.onSkillsClick();
                }
            }
        );

        this.container.add([
            this.bg,
            this.characterButton,
            this.inventoryButton,
            this.skillsButton
        ]);
    }

    createButton(x, y, width, height, label, onClick) {
        const buttonBg = this.scene.add.rectangle(0, 0, width, height, 0x000000);
        buttonBg.setOrigin(0, 0);
        buttonBg.setStrokeStyle(1, 0x752438);
        buttonBg.setInteractive(
            new Phaser.Geom.Rectangle(0, 0, width, height),
            Phaser.Geom.Rectangle.Contains
        );

        const text = addText(this.scene, {
            x: width / 2,
            y: height / 2,
            text: label,
            size: 20,
            color: TEXT_COLOR,
            originX: 0.5,
            originY: 0.5
        });

        const buttonContainer = this.scene.add.container(x, y, [buttonBg, text]);

        buttonBg.on("pointerdown", onClick);

        buttonBg.on("pointerover", () => {
            this.scene.cursorManager.setState("pointer");
            buttonBg.setFillStyle(0x221111);
        });

        buttonBg.on("pointerout", () => {
            this.scene.cursorManager.setState("default");
            buttonBg.setFillStyle(0x000000);
        });

        return buttonContainer;
    }
}