export default class DraggablePanel {
  constructor(scene, x, y, width, height) {
    this.scene = scene;
    this.panelWidth = width;
    this.panelHeight = height;

    this.isDragging = false;
    this.dragOffSetX = 0;
    this.dragOffSetY = 0;

    this.container = this.scene.add.container(x, y);

    this.panelBg = this.scene.add.graphics();
    this.panelBg.fillStyle(0x090A14, 1);
    this.panelBg.lineStyle(2, 0x752438, 1);
    this.panelBg.fillRect(
      -this.panelWidth / 2,
      -this.panelHeight / 2,
      this.panelWidth,
      this.panelHeight
    );
    this.panelBg.strokeRect(
      -this.panelWidth / 2,
      -this.panelHeight / 2,
      this.panelWidth,
      this.panelHeight
    );

    this.container.add(this.panelBg);

    this.panelBg.setInteractive(
      new Phaser.Geom.Rectangle(
        -this.panelWidth / 2,
        -this.panelHeight / 2,
        this.panelWidth,
        this.panelHeight
      ),
      Phaser.Geom.Rectangle.Contains
    );

    this.panelBg.on("pointerdown", (pointer) => {
      if (this.isPointerOnBlockedObject(pointer)) return;

      this.isDragging = true;
      this.dragOffSetX = pointer.worldX - this.container.x;
      this.dragOffSetY = pointer.worldY - this.container.y;
    });

    this.scene.input.on("pointermove", (pointer) => {
      if (!this.isDragging || !pointer.isDown) return;

      this.container.x = pointer.worldX - this.dragOffSetX;
      this.container.y = pointer.worldY - this.dragOffSetY;
    });

    this.scene.input.on("pointerup", () => {
      this.isDragging = false;
    });

    this.scene.input.on("pointerupoutside", () => {
      this.isDragging = false;
    });

    this.scene.input.on("gameout", () => {
      this.isDragging = false;
    });

    this.blockDragObjects = [];
  }

  add(child) {
    this.container.add(child);
    return child;
  }

  addBlockDragObject(gameObject) {
    this.blockDragObjects.push(gameObject);
    return gameObject;
  }

  isPointerOnBlockedObject(pointer) {
    for (const obj of this.blockDragObjects) {
      if (!obj || !obj.getBounds) continue;

      const bounds = obj.getBounds();
      if (bounds.contains(pointer.worldX, pointer.worldY)) {
        return true;
      }
    }
    return false;
  }

  setPosition(x, y) {
    this.container.setPosition(x, y);
  }

  destroy() {
    this.container.destroy(true);
  }
}