import Phaser from "phaser";
import DraggablePanel from "./DraggablePanel.js";
import { ITEM_DATA } from "../data/itemData.js";
import ItemActionMenu from "./ItemActionMenu.js";


export default class InventoryPanel extends DraggablePanel {
  constructor(scene, x, y, inventorySystem) {
    super(scene, x, y, 320, 320);

    this.scene = scene;
    this.inventorySystem = inventorySystem;
    this.itemActionMenu = new ItemActionMenu(this.scene, {
        onUse: (entry) => this.handleUse(entry),
        onDrop: (entry) => this.handleDrop(entry),
        onObserve: (entry) => this.handleObserve(entry),
        onEat: (entry) => this.handleEat(entry),
        onEquip: (entry) => this.handleEquip(entry)
    });

    this.layout = {
      cols: 5,
      rows: 4,
      slotSize: 48,
      slotGap: 8,
      startX: -132,
      startY: -92,
      quantityOffsetX: 5,
      quantityOffsetY: 5
    };

    this.slotObjects = [];
    this.itemObjects = [];

    this.closeButton = this.scene.add.image(
      this.panelWidth / 2 - 23,
      -this.panelHeight / 2 + 5,
      "close"
    );
    this.closeButton.setOrigin(0, 0);
    this.closeButton.setInteractive();

    this.hoverRectangle = this.scene.add.graphics();
    this.hoverRectangle.lineStyle(1, 0x00ff00, 1);
    this.hoverRectangle.strokeRect(
      this.closeButton.x,
      this.closeButton.y,
      this.closeButton.displayWidth,
      this.closeButton.displayHeight
    );
    this.hoverRectangle.setAlpha(0);

    this.titleText = this.scene.add.bitmapText(
        0,
        -130,
      "font01",
      "Inventory",
      20

    );
    this.titleText.setOrigin(0.5);

    this.add(this.titleText);
    this.add(this.closeButton);
    this.add(this.hoverRectangle);

    this.addBlockDragObject(this.closeButton);

    this.closeButton.on("pointerdown", () => {
      this.hide();
    });

    this.closeButton.on("pointerover", () => {
      this.scene.cursorManager.setState("pointer");
      this.hoverRectangle.setAlpha(1);
    });

    this.closeButton.on("pointerout", () => {
      this.scene.cursorManager.setState("default");
      this.hoverRectangle.setAlpha(0);
    });

    this.createSlots();
    this.refresh();

    this.container.setDepth(5100);
  }

  createSlots() {
    const { cols, rows, slotSize, slotGap, startX, startY } = this.layout;

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const x = startX + col * (slotSize + slotGap);
        const y = startY + row * (slotSize + slotGap);

        const bg = this.scene.add.rectangle(x, y, slotSize, slotSize, 0x111111);
        bg.setOrigin(0, 0);
        bg.setStrokeStyle(1, 0x752438);

        this.slotObjects.push(bg);
        this.add(bg);
      }
    }
  }

  clearItemObjects() {
    this.itemObjects.forEach((obj) => obj.destroy());
    this.itemObjects = [];
  }

  refresh() {
    this.clearItemObjects();

    const items = this.inventorySystem.getItems();
    const { cols, slotSize, slotGap, startX, startY, quantityOffsetX, quantityOffsetY } = this.layout;

    items.forEach((entry, index) => {
      const itemDef = ITEM_DATA[entry.defId];
      if (!itemDef) {
        return;
      }

      const col = index % cols;
      const row = Math.floor(index / cols);

      const x = startX + col * (slotSize + slotGap);
      const y = startY + row * (slotSize + slotGap);

      const icon = this.scene.add.sprite(
        x + slotSize / 2,
        y + slotSize / 2,
        itemDef.iconSheet,
        itemDef.frame
      );
      icon.setInteractive();
      icon.on("pointerdown", (pointer) => {
        if(pointer.leftButtonDown()) {
            this.handleItemClick(entry);
            return;
        } 

        if(pointer.rightButtonDown()) {
            this.itemActionMenu.show(entry,pointer.worldX, pointer.worldY);
            return;
        }
      });

      icon.on("pointerover", () => {
        this.scene.cursorManager.setState("pointer");
      });

      icon.on("pointerout", () => {
        this.scene.cursorManager.setState("default");
      });

      this.addBlockDragObject(icon);
      this.add(icon);
      this.itemObjects.push(icon);

      if (itemDef.stackable && entry.quantity > 1) {
        const qtyText = this.scene.add.bitmapText(
          x + slotSize - quantityOffsetX,
          y + slotSize - quantityOffsetY,
          "font01",
          String(entry.quantity),
          14
        );
        qtyText.setOrigin(1, 1);

        this.add(qtyText);
        this.itemObjects.push(qtyText);
      }
    });
  }

  hide() {
    this.container.setAlpha(0);
    this.scene.cursorManager.setState("default");
    this.hoverRectangle.setAlpha(0);
    this.panelBg.disableInteractive();
    this.closeButton.disableInteractive();
    this.isDragging = false;
  }

  handleItemClick(entry) {
    const itemDef = ITEM_DATA[entry.defId];
    if(!itemDef) return;

    if(itemDef.type === "food") {
        this.scene.playerState.heal(1);
        
        this.inventorySystem.removeItemByUid(entry.uid,1);

        this.refresh();
    }
  }

  show() {
    this.container.setAlpha(1);

    this.panelBg.setInteractive(
      new Phaser.Geom.Rectangle(
        -this.panelWidth / 2,
        -this.panelHeight / 2,
        this.panelWidth,
        this.panelHeight
      ),
      Phaser.Geom.Rectangle.Contains
    );

    this.closeButton.setInteractive();
    this.refresh();
  }

  handleUse(entry) {
    if (!entry) return;

    const itemDef = ITEM_DATA[entry.itemDef];
    if(!itemDef) return;

    console.log("Use:", itemDef.Name);
  }

  handleDrop(entry) {
    if(!entry) return;

    this.inventorySystem.removeItemByUid(entry.uid,1);
    this.refresh();
  }

  handleObserve(entry) {
    if (!entry) return;

    const itemDef = ITEM_DATA[entry.defId];
    if (!itemDef) return;

    console.log("Observe:", itemDef);
  }

  handleEat(entry) {
    if(!entry) return;

    const itemDef = ITEM_DATA[entry.defId];
    if(!itemDef || itemDef.type !== "food") return;

    this.scene.playerState.heal(1);
    this.inventorySystem.removeItemByUid(entry.uid,1);
    this.refresh();
  }

  handleEquip(entry) {
    if (!entry) return;

    const itemDef = ITEM_DATA[entry.defId];
    if (!itemDef) return;

    console.log("Equip:", itemDef.name);
  }
}