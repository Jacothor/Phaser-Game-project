import Phaser from "phaser";
import { addText } from "../utils/addText";
const TEXT_COLOR = 0xffffff;

export default class MapNode {
  constructor(scene, parentContainer, nodeData, eventBus) {
    this.eventBus = eventBus;
    this.scene = scene;
    this.parentContainer = parentContainer;
    this.nodeData = nodeData;

    this.isSelected = false;
    this.isHovered = false;
    this.currentState = nodeData.defaultState ?? "default";

    this.homeX = nodeData.mapX ?? nodeData.x ?? 0;
    this.homeY = nodeData.mapY ?? nodeData.y ?? 0;

    this.container = this.scene.add.container(this.homeX, this.homeY);

    this.label = addText(this.scene, {
      x: 0,
      y: -30,
      text: nodeData.label || nodeData.name || nodeData.id || "",
      size: 20,
      color: TEXT_COLOR,
      originX: 0.5,
      originY: 0.5
    });

    this.icon = this.scene.add.sprite(
      0,
      0,
      nodeData.iconSheet || "RPG",
      nodeData.iconFrame ?? 0
    );

    this.icon.setDisplaySize(16, 16);
    this.icon.setDepth(1);
    this.icon.setInteractive();

    this.container.add([this.icon, this.label]);
    this.parentContainer.add(this.container);

    this.hoverTween = null;
    this.patrolTween = null;
    this.isPatrolPaused = false;

    this.bindEvents();
    this.refreshVisual();
    this.startPatrolIfNeeded();
  }

  bindEvents() {
    this.icon.on("pointerover", () => {
      this.isHovered = true;

      if (this.scene.cursorManager) {
        this.scene.cursorManager.setState("pointer");
      }

      this.startHoverAnim();

      this.refreshVisual();
    });

    this.icon.on("pointerout", () => {
      this.isHovered = false;

      if (this.scene.cursorManager) {
        this.scene.cursorManager.setState("default");
      }

      this.stopHoverAnim();


      this.refreshVisual();
    });

    this.icon.on("pointerdown", (pointer) => {
      if (pointer.rightButtonDown()) {

        return;
      }
      //NEW
      this.eventBus.emit("node.clicked", {
        nodeId: this.nodeData.id,
        nodeData: this.nodeData
      });

      
    });
  }

  startPatrolIfNeeded() {
    if (this.nodeData.type !== "enemy") return;

    const radius = this.nodeData.patrolRadius ?? 0;
    if (radius <= 0) return;

    const speed = this.nodeData.patrolSpeed ?? 1200;

    this.moveToRandomPatrolPoint(speed);
  }

  moveToRandomPatrolPoint(duration = 1200) {
    if (this.isPatrolPaused) return;

    const radius = this.nodeData.patrolRadius ?? 0;
    if (radius <= 0) return;

    const angle = Phaser.Math.FloatBetween(0, Math.PI * 2);
    const distance = Phaser.Math.FloatBetween(4, radius);

    const targetX = this.homeX + Math.cos(angle) * distance;
    const targetY = this.homeY + Math.sin(angle) * distance;

    this.patrolTween = this.scene.tweens.add({
      targets: this.container,
      x: targetX,
      y: targetY,
      duration,
      ease: "Sine.easeInOut",
      onComplete: () => {
        this.patrolTween = null;

        if (this.isPatrolPaused) return;

        const nextDelay = Phaser.Math.Between(300, 900);

        this.scene.time.delayedCall(nextDelay, () => {
          if (!this.container || !this.container.active) return;
          if (this.isPatrolPaused) return;

          this.moveToRandomPatrolPoint(duration);
        });
      }
    });
  }

  pausePatrol() {
    this.isPatrolPaused = true;

    if (this.patrolTween) {
      this.patrolTween.pause();
    }

    this.refreshVisual();
  }

  resumePatrol() {
    this.isPatrolPaused = false;

    if (!this.container || !this.container.active) return;
    if (!this.container.visible) return;

    if (this.patrolTween) {
      this.patrolTween.resume();
      return;
    }

    const speed = this.nodeData.patrolSpeed ?? 1200;
    this.moveToRandomPatrolPoint(speed);
  }

  startHoverAnim() {
    this.scene.tweens.killTweensOf(this.icon);

    this.scene.tweens.add({
      targets: this.icon,
      scaleX: 1.2,
      scaleY: 1.2,
      y: -4,
      duration: 150,
      ease: "Back.easeOut"
    });
  }

  stopHoverAnim() {
    this.scene.tweens.killTweensOf(this.icon);

    this.scene.tweens.add({
      targets: this.icon,
      scaleX: 1,
      scaleY: 1,
      y: 0,
      duration: 120,
      ease: "Quad.easeOut"
    });

    this.hoverTween = null;
  }

  setSelected(value) {
    this.isSelected = value;
    this.refreshVisual();
  }

  setState(stateName) {
    this.currentState = stateName ?? "default";
    this.refreshVisual();
  }

  setVisible(value) {
    this.container.setVisible(value);
  }

  getId() {
    return this.nodeData.id;
  }

  getData() {
    return this.nodeData;
  }

  getState() {
    return this.currentState;
  }

  refreshVisual() {
    let alpha = 1;
    let tint = 0xffffff;

    if (this.isHovered) {
      tint = 0xffd588;
    }

    switch (this.currentState) {
      case "hidden":
        alpha = 0;
        break;

      case "defeated":
      case "harvested":
      case "opened":
      case "looted":
        alpha = 0.6;
        tint = 0x777777;
        break;

      case "moved":
      case "revealed":
      case "active":
        tint = 0xaaffcc;
        break;

      case "blocked":
        tint = 0xff8888;
        break;
    }

    if (this.isSelected && alpha > 0) {
      tint = 0xffd166;
    }

    if (this.isPatrolPaused && alpha > 0 ) {
      tint = 0xff0000;
    }

    this.label.setVisible(alpha > 0 && this.isHovered);

    this.icon.setTint(tint);
    this.container.setAlpha(alpha);
    this.container.setVisible(alpha > 0);
  }

  destroy() {
    if (this.hoverTween) {
      this.hoverTween.stop();
      this.hoverTween = null;
    }

    if (this.patrolTween) {
      this.patrolTween.stop();
      this.patrolTween = null;
    }

    this.container.destroy(true);
  }
}