import Phaser from "phaser";
import DraggablePanel from "./DraggablePanel";
import { PLAYER_ANIMATIONS, PLAYER_CONFIG, PLAYER_STATES } from "../data/playerPanelData";

export default class Player extends DraggablePanel {
  constructor(scene, x, y) {
    super(scene, x, y, 260, 260);
    this.scene = scene;

    this.isInCombat = false;
    this.latestBattleState = null;
    this.isHoveringHpBar = false;

    this.layout = {
      barX: -100,
      hpBarY: 60,
      gaugeBarY: 115,
      hpBarWidth: 200,
      gaugeBarWidth: 200,
      barHeight: 10,

      hpHoverOffsetX: 8,
      hpHoverOffsetY: -22,

      damageTextX: 0,
      damageTextY: -40
    };

    this.closeButton = this.scene.add.image(
      this.panelWidth / 2 - 23,
      -this.panelHeight / 2 + 5,
      "close"
    );
    this.closeButton.setOrigin(0, 0);
    this.closeButton.setInteractive();

    this.hoverRectangle = this.scene.add.graphics();
    this.hoverRectangle.lineStyle(1, 0x00ff00, 1);
    this.hoverRectangle
      .strokeRect(
        this.closeButton.x,
        this.closeButton.y,
        this.closeButton.displayWidth,
        this.closeButton.displayHeight
      )
      .setAlpha(0);
    this.add(this.hoverRectangle);

    this.sprite = this.scene.add.sprite(0, -35, "player-idle-1");
    this.sprite.setScale(PLAYER_CONFIG.scale);

    this.hpBarBg = this.scene.add.graphics();
    this.hpBarFill = this.scene.add.graphics();
    this.gaugeBarBg = this.scene.add.graphics();
    this.gaugeBarFill = this.scene.add.graphics();

    this.hpBarHitArea = this.scene.add.zone(
      this.layout.barX + this.layout.hpBarWidth / 2,
      this.layout.hpBarY + this.layout.barHeight / 2,
      this.layout.hpBarWidth,
      this.layout.barHeight
    );
    this.hpBarHitArea.setOrigin(0.5, 0.5);
    this.hpBarHitArea.setRectangleDropZone(
      this.layout.hpBarWidth,
      this.layout.barHeight
    );
    this.hpBarHitArea.setInteractive({ useHandCursor: false });

    this.hpTooltipBg = this.scene.add.graphics();
    this.hpTooltipText = this.scene.add.text(0, 0, "0 / 0", {
      fontFamily: "Arial",
      fontSize: "12px",
      color: "#ffffff"
    });
    this.hpTooltipBg.setVisible(false);
    this.hpTooltipText.setVisible(false);
    this.hpTooltipBg.setDepth(5001);
    this.hpTooltipText.setDepth(5002);

    this.hpBarHitArea.on("pointerover", () => {
      this.isHoveringHpBar = true;
      this.hpTooltipBg.setVisible(true);
      this.hpTooltipText.setVisible(true);
    });

    this.hpBarHitArea.on("pointerout", () => {
      this.isHoveringHpBar = false;
      this.hpTooltipBg.setVisible(false);
      this.hpTooltipText.setVisible(false);
    });

    this.add(this.closeButton);
    this.add(this.sprite);
    this.add(this.hpBarBg);
    this.add(this.hpBarFill);
    this.add(this.gaugeBarBg);
    this.add(this.gaugeBarFill);
    this.add(this.hpBarHitArea);

    this.addBlockDragObject(this.closeButton);
    this.addBlockDragObject(this.hpBarHitArea);

    this.closeButton.on("pointerdown", () => {
      this.hide();
    });

    this.closeButton.on("pointerover", () => {
      this.scene.cursorManager.setState("pointer");
      this.hoverRectangle.setAlpha(1);
    });

    this.closeButton.on("pointerout", () => {
      this.scene.cursorManager.setState("default");
      this.hoverRectangle.setAlpha(0);
    });

    this.container.setDepth(5000);

    this.currentState = null;
    this.defaultNonCombatState = PLAYER_CONFIG.defaultState;

    this.setState(PLAYER_CONFIG.defaultState);
    this.refreshUI();
  }

  setState(state) {
    if (this.currentState === state) return;

    const anim = PLAYER_ANIMATIONS[state];
    if (!anim) {
      console.warn(`Unknown player animation state: ${state}`);
      return;
    }

    this.currentState = state;
    this.sprite.play(anim.key);
  }

  playOneShotState(state, fallbackState = null) {
    const anim = PLAYER_ANIMATIONS[state];
    if (!anim) {
      console.warn(`Unknown one-shot animation state: ${state}`);
      return;
    }

    this.currentState = state;
    this.sprite.play(anim.key);

    if (anim.repeat === 0 && fallbackState) {
      this.sprite.once("animationcomplete", () => {
        this.setState(fallbackState);
      });
    }
  }

  syncBattleState(battleState) {
    this.latestBattleState = battleState;
    this.isInCombat = !!battleState;
    this.refreshUI();
  }

  enterBattleStance() {
    this.isInCombat = true;
    this.setState(PLAYER_STATES.SWORDIDLE);
    this.refreshUI();
  }

  exitBattleStance() {
    this.isInCombat = false;
    this.latestBattleState = null;
    this.setState(this.defaultNonCombatState);
    this.refreshUI();
  }

  playAttackAnim() {
    this.playOneShotState(PLAYER_STATES.SWORDSLASH, PLAYER_STATES.SWORDIDLE);
  }

  playGuardAnim() {
    this.playOneShotState(PLAYER_STATES.GUARD, PLAYER_STATES.SWORDIDLE);
  }

  playDamageAnim() {
    this.playOneShotState(PLAYER_STATES.DAMAGE, PLAYER_STATES.SWORDIDLE);
  }

  playDeathAnim() {
    this.setState(PLAYER_STATES.DIE);
  }

  drawBarPair(bgGraphics, fillGraphics, x, y, width, ratio, fillColor) {
    const clampedRatio = Phaser.Math.Clamp(ratio, 0, 1);

    bgGraphics.clear();
    bgGraphics.fillStyle(0x222222, 1);
    bgGraphics.lineStyle(1, 0xffffff, 1);
    bgGraphics.fillRect(x, y, width, this.layout.barHeight);
    bgGraphics.strokeRect(x, y, width, this.layout.barHeight);

    fillGraphics.clear();
    fillGraphics.fillStyle(fillColor, 1);
    fillGraphics.fillRect(x, y, width * clampedRatio, this.layout.barHeight);
  }

  getHealthColor(ratio) {
    if (ratio <= 0.25) return 0xff4d4d;
    if (ratio <= 0.5) return 0xffc857;
    return 0x4caf50;
  }

  updateHpTooltip() {
    if (!this.isHoveringHpBar) return;

    const pointer = this.scene.input.activePointer;
    if (!pointer) return;

    const textX = pointer.worldX + this.layout.hpHoverOffsetX;
    const textY = pointer.worldY + this.layout.hpHoverOffsetY;

    this.hpTooltipText.setPosition(textX, textY);

    const bounds = this.hpTooltipText.getBounds();
    const padX = 4;
    const padY = 2;

    this.hpTooltipBg.clear();
    this.hpTooltipBg.fillStyle(0x000000, 0.9);
    this.hpTooltipBg.lineStyle(1, 0xffffff, 1);
    this.hpTooltipBg.fillRect(
      bounds.x - padX,
      bounds.y - padY,
      bounds.width + padX * 2,
      bounds.height + padY * 2
    );
    this.hpTooltipBg.strokeRect(
      bounds.x - padX,
      bounds.y - padY,
      bounds.width + padX * 2,
      bounds.height + padY * 2
    );
  }

  showDamageEffect({ hit, damage }) {
    const showMiss = !hit || damage <= 0;
    const textValue = showMiss ? "MISS" : String(damage);

    const worldMatrix = this.sprite.getWorldTransformMatrix();
    const worldX = worldMatrix.tx;
    const worldY = worldMatrix.ty;

    const dmgText = this.scene.add.bitmapText(
      worldX + this.layout.damageTextX,
      worldY + this.layout.damageTextY,
      "font01",
      textValue,
      18
    );

    dmgText.setOrigin(0.5);
    dmgText.setDepth(6001);
    dmgText.setAlpha(1);

    this.scene.time.delayedCall(1000, () => {
      if (!dmgText || !dmgText.scene) return;

      this.scene.tweens.add({
        targets: dmgText,
        y: dmgText.y - 18,
        alpha: 0,
        duration: 250,
        ease: "Power1",
        onComplete: () => {
          if (dmgText && dmgText.scene) {
            dmgText.destroy();
          }
        }
      });
    });
  }

  refreshUI() {
    if (!this.scene.playerState) {
      return;
    }

    const stats = this.scene.playerState.getStats();
    const health = stats.health ?? 0;
    const maxHealth = stats.maxHealth ?? 1;
    const hpRatio = Phaser.Math.Clamp(health / Math.max(1, maxHealth), 0, 1);

    this.hpTooltipText.setText(`${health} / ${maxHealth}`);

    this.drawBarPair(
      this.hpBarBg,
      this.hpBarFill,
      this.layout.barX,
      this.layout.hpBarY,
      this.layout.hpBarWidth,
      hpRatio,
      this.getHealthColor(hpRatio)
    );

    this.hpBarHitArea.setPosition(
      this.layout.barX + this.layout.hpBarWidth / 2,
      this.layout.hpBarY + this.layout.barHeight / 2
    );
    this.hpBarHitArea.setSize(
      this.layout.hpBarWidth,
      this.layout.barHeight
    );

    const playerGauge = this.latestBattleState?.player?.gauge ?? 0;
    const gaugeRatio = Phaser.Math.Clamp(playerGauge / 100, 0, 1);

    this.gaugeBarBg.setVisible(this.isInCombat);
    this.gaugeBarFill.setVisible(this.isInCombat);

    if (this.isInCombat) {
      this.drawBarPair(
        this.gaugeBarBg,
        this.gaugeBarFill,
        this.layout.barX,
        this.layout.gaugeBarY,
        this.layout.gaugeBarWidth,
        gaugeRatio,
        0x66ccff
      );
    } else {
      this.gaugeBarBg.clear();
      this.gaugeBarFill.clear();
    }
  }

  hide() {
    this.container.setAlpha(0);
    this.scene.cursorManager.setState("default");
    this.hoverRectangle.setAlpha(0);
    this.hpTooltipBg.setVisible(false);
    this.hpTooltipText.setVisible(false);
    this.isHoveringHpBar = false;
    this.panelBg.disableInteractive();
    this.closeButton.disableInteractive();
    this.hpBarHitArea.disableInteractive();
    this.isDragging = false;
  }

  show() {
    this.container.setAlpha(1);

    this.panelBg.setInteractive(
      new Phaser.Geom.Rectangle(
        -this.panelWidth / 2,
        -this.panelHeight / 2,
        this.panelWidth,
        this.panelHeight
      ),
      Phaser.Geom.Rectangle.Contains
    );

    this.closeButton.setInteractive();
    this.hpBarHitArea.setInteractive({ useHandCursor: false });
  }

  update() {
    this.refreshUI();
    this.updateHpTooltip();
  }
}