import MapNode from "./MapNode";

export default class MapUI {
  constructor(scene, x, y, mapData, playerWorldState, eventBus) {
    this.eventBus = eventBus;
    this.scene = scene;
    this.x = x;
    this.y = y;
    this.mapData = mapData || { id: "default", name: "Map", nodes: [] };
    this.playerWorldState = playerWorldState;
    this.isBattleLocked = false;

    this.nodes = new Map();
    this.selectedNodeId = null;

    this.container = this.scene.add.container(x, y);

    this.bg = this.scene.add.image(0, 0, "map_bg").setOrigin(0, 0);
    this.bg.setDisplaySize(640, 420); // match your UI size

    this.titleText = this.scene.add.text(20, 15, this.mapData.name || "", {
      fontFamily: "font01",
      fontSize: "20px",
      color: "#752438"
    });

    this.nodesContainer = this.scene.add.container(0, 0);

    this.container.add([this.bg, this.titleText, this.nodesContainer]);

    this.render();
  }

  setMapData(mapData) {
    this.mapData = mapData || { id: "default", name: "Map", nodes: [] };
    this.selectedNodeId = null;
    this.titleText.setText(this.mapData.name || "MAP");
    this.render();
  }

  setPlayerWorldState(playerWorldState) {
    this.playerWorldState = playerWorldState;
    this.refreshFromWorldState();
  }

  render() {
    this.clearNodes();
    this.createNodesFromData();
    this.refreshFromWorldState();
  }

  clearNodes() {
    this.nodes.forEach((node) => node.destroy());
    this.nodes.clear();
    this.nodesContainer.removeAll(true);
  }

  createNodesFromData() {
    const nodes = this.mapData.nodes || [];

    nodes.forEach((nodeData) => {
      const node = new MapNode(this.scene, this.nodesContainer, nodeData, this.eventBus);

      this.nodes.set(nodeData.id, node);
    });
  }

  handleNodeLeftClick(node, pointer) {
    if (this.isBattleLocked) {
        return;
    }
  }

  handleNodeRightClick(node, pointer) {
    if (this.isBattleLocked) {
        return;
    }

  }

  selectNode(nodeId) {
    this.selectedNodeId = nodeId;

    this.nodes.forEach((node, id) => {
      node.setSelected(id === nodeId);
    });
  }

  unselectNode() {
    this.selectedNodeId = null;
    this.nodes.forEach((node) => {
        node.setSelected(false);
    })
  }

  refreshFromWorldState() {
    const mapNodes = this.mapData.nodes || [];

    mapNodes.forEach((nodeData) => {
      const node = this.nodes.get(nodeData.id);
      if (!node) return;

      const defaultState = nodeData.defaultState ?? "default";
      const currentState = this.playerWorldState
        ? this.playerWorldState.getNodeState(nodeData.id, defaultState)
        : defaultState;

      node.setState(currentState);

      const isVisible = this.isNodeVisible(nodeData, currentState);
      node.setVisible(isVisible);
    });

    if (this.selectedNodeId && this.nodes.has(this.selectedNodeId)) {
        const selectedNode = this.nodes.get(this.selectedNodeId);

        if (selectedNode.visible) {
            selectedNode.setSelected(true);
        } else {
            this.unselectNode();
        }
    }
  }

  isNodeVisible(nodeData, currentState) {
    if (currentState === "hidden") {
      return false;
    }

    if (typeof nodeData.isVisible === "boolean") {
      return nodeData.isVisible;
    }

    return true;
  }

  setBattleLocked(value) {
    this.isBattleLocked = value;
  }

  getBattleLocked() {
    return this.isBattleLocked;
  }

  getNodeById(nodeId) {
    return this.nodes.get(nodeId) || null;
  }

  getNodeState(nodeId) {
    const nodeData = (this.mapData.nodes || []).find((node) => node.id === nodeId);

    if (!nodeData) {
      return null;
    }

    const defaultState = nodeData.defaultState ?? "default";

    return this.playerWorldState
      ? this.playerWorldState.getNodeState(nodeId, defaultState)
      : defaultState;
  }

  destroy() {
    this.clearNodes();
    this.container.destroy(true);
  }
}