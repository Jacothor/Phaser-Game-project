import Phaser from "phaser";
import DraggablePanel from "./DraggablePanel";
import { ENEMY_DATA } from "../data/enemiesData";
import { addText } from "../utils/addText.js";

const TEXT_COLOR = 0xffffff;

export default class BattlePanel extends DraggablePanel {
  constructor(scene, x, y) {
    super(scene, x, y, 260, 260);
    this.scene = scene;

    this.currentEnemyId = null;
    this.latestBattleState = null;
    this.isHoveringHpBar = false;

    this.layout = {
      barX: -100,
      hpBarY: 65,
      gaugeBarY: 120,
      hpBarWidth: 200,
      gaugeBarWidth: 200,
      barHeight: 10,

      hpHoverOffsetX: 8,
      hpHoverOffsetY: -22,

      damageTextX: 0,
      damageTextY: -40
    };

    this.closeButton = this.scene.add.image(
      this.panelWidth / 2 - 23,
      -this.panelHeight / 2 + 5,
      "close"
    );
    this.closeButton.setOrigin(0, 0);
    this.closeButton.setInteractive();

    this.hoverRectangle = this.scene.add.graphics();
    this.hoverRectangle.lineStyle(1, 0x00ff00, 1);
    this.hoverRectangle.strokeRect(
      this.closeButton.x,
      this.closeButton.y,
      this.closeButton.displayWidth,
      this.closeButton.displayHeight
    );
    this.hoverRectangle.setAlpha(0);

    this.enemySprite = this.scene.add.sprite(0, -25, "gray_wolf", 0);
    this.enemySprite.setOrigin(0.5, 0.5);
    this.enemySprite.setScale(2);

    this.enemyNameText = addText(this.scene, {
      x: 0,
      y: -95,
      text: "",
      size: 20,
      color: TEXT_COLOR,
      originX: 0.5,
      originY: 0.5
    });

    this.enemyHpBarBg = this.scene.add.graphics();
    this.enemyHpBarFill = this.scene.add.graphics();
    this.enemyGaugeBarBg = this.scene.add.graphics();
    this.enemyGaugeBarFill = this.scene.add.graphics();

    this.enemyHpBarHitArea = this.scene.add.zone(
      this.layout.barX + this.layout.hpBarWidth / 2,
      this.layout.hpBarY + this.layout.barHeight / 2,
      this.layout.hpBarWidth,
      this.layout.barHeight
    );
    this.enemyHpBarHitArea.setOrigin(0.5, 0.5);
    this.enemyHpBarHitArea.setRectangleDropZone(
      this.layout.hpBarWidth,
      this.layout.barHeight
    );
    this.enemyHpBarHitArea.setInteractive({ useHandCursor: false });

    this.enemyHpTooltipBg = this.scene.add.graphics();
    this.enemyHpTooltipText = this.scene.add.text(0, 0, "0 / 0", {
      fontFamily: "Arial",
      fontSize: "12px",
      color: "#ffffff"
    });
    this.enemyHpTooltipBg.setVisible(false);
    this.enemyHpTooltipText.setVisible(false);
    this.enemyHpTooltipBg.setDepth(5001);
    this.enemyHpTooltipText.setDepth(5002);

    this.enemyHpBarHitArea.on("pointerover", () => {
      this.isHoveringHpBar = true;
      this.enemyHpTooltipBg.setVisible(true);
      this.enemyHpTooltipText.setVisible(true);
    });

    this.enemyHpBarHitArea.on("pointerout", () => {
      this.isHoveringHpBar = false;
      this.enemyHpTooltipBg.setVisible(false);
      this.enemyHpTooltipText.setVisible(false);
    });

    this.add(this.closeButton);
    this.add(this.hoverRectangle);
    this.add(this.enemyNameText);
    this.add(this.enemySprite);
    this.add(this.enemyHpBarBg);
    this.add(this.enemyHpBarFill);
    this.add(this.enemyGaugeBarBg);
    this.add(this.enemyGaugeBarFill);
    this.add(this.enemyHpBarHitArea);

    this.addBlockDragObject(this.closeButton);
    this.addBlockDragObject(this.enemyHpBarHitArea);

    this.closeButton.on("pointerdown", () => {
      this.hide();
    });

    this.closeButton.on("pointerover", () => {
      this.scene.cursorManager.setState("pointer");
      this.hoverRectangle.setAlpha(1);
    });

    this.closeButton.on("pointerout", () => {
      this.scene.cursorManager.setState("default");
      this.hoverRectangle.setAlpha(0);
    });

    this.setEnemy("gray_wolf");
    this.refreshBattleUI();
  }

  setEnemy(enemyId) {
    const enemyData = ENEMY_DATA[enemyId];
    if (!enemyData) {
      console.warn(`Enemy not found: ${enemyId}`);
      return;
    }

    this.currentEnemyId = enemyId;
    this.enemySprite.setTexture(enemyData.ID, 0);
    this.playEnemyAnim("idle");
    this.enemyNameText.setText((enemyData.name || enemyData.ID).toUpperCase());
  }

  playEnemyAnim(animKey) {
    if (!this.currentEnemyId) return;

    const fullAnimKey = `${this.currentEnemyId}-${animKey}`;
    this.enemySprite.play(fullAnimKey);

    if (animKey !== "idle") {
      this.enemySprite.once("animationcomplete", () => {
        this.playEnemyAnim("idle");
      });
    }
  }

  syncBattleState(battleState) {
    this.latestBattleState = battleState;
    this.refreshBattleUI();
  }

  drawBarPair(bgGraphics, fillGraphics, x, y, width, ratio, fillColor = 0x4caf50) {
    const clampedRatio = Phaser.Math.Clamp(ratio, 0, 1);

    bgGraphics.clear();
    bgGraphics.fillStyle(0x222222, 1);
    bgGraphics.lineStyle(1, 0xffffff, 1);
    bgGraphics.fillRect(x, y, width, this.layout.barHeight);
    bgGraphics.strokeRect(x, y, width, this.layout.barHeight);

    fillGraphics.clear();
    fillGraphics.fillStyle(fillColor, 1);
    fillGraphics.fillRect(x, y, width * clampedRatio, this.layout.barHeight);
  }

  getHealthColor(ratio) {
    if (ratio <= 0.25) return 0xff4d4d;
    if (ratio <= 0.5) return 0xffc857;
    return 0x4caf50;
  }

  updateHpTooltip() {
    if (!this.isHoveringHpBar) return;

    const pointer = this.scene.input.activePointer;
    if (!pointer) return;

    const textX = pointer.worldX + this.layout.hpHoverOffsetX;
    const textY = pointer.worldY + this.layout.hpHoverOffsetY;

    this.enemyHpTooltipText.setPosition(textX, textY);

    const bounds = this.enemyHpTooltipText.getBounds();
    const padX = 4;
    const padY = 2;

    this.enemyHpTooltipBg.clear();
    this.enemyHpTooltipBg.fillStyle(0x000000, 0.9);
    this.enemyHpTooltipBg.lineStyle(1, 0xffffff, 1);
    this.enemyHpTooltipBg.fillRect(
      bounds.x - padX,
      bounds.y - padY,
      bounds.width + padX * 2,
      bounds.height + padY * 2
    );
    this.enemyHpTooltipBg.strokeRect(
      bounds.x - padX,
      bounds.y - padY,
      bounds.width + padX * 2,
      bounds.height + padY * 2
    );
  }

  showDamageEffect({ hit, damage }) {
    const showMiss = !hit || damage <= 0;
    const textValue = showMiss ? "MISS" : String(damage);

    const worldMatrix = this.enemySprite.getWorldTransformMatrix();
    const worldX = worldMatrix.tx;
    const worldY = worldMatrix.ty;

    const dmgText = this.scene.add.bitmapText(
      worldX + this.layout.damageTextX,
      worldY + this.layout.damageTextY,
      "font01",
      textValue,
      18
    );

    dmgText.setOrigin(0.5);
    dmgText.setDepth(6001);
    dmgText.setAlpha(1);

    this.scene.time.delayedCall(1000, () => {
      if (!dmgText || !dmgText.scene) return;

      this.scene.tweens.add({
        targets: dmgText,
        y: dmgText.y - 18,
        alpha: 0,
        duration: 250,
        ease: "Power1",
        onComplete: () => {
          if (dmgText && dmgText.scene) {
            dmgText.destroy();
          }
        }
      });
    });
  }

  refreshBattleUI() {
    const battleState = this.latestBattleState;

    if (!battleState) {
      this.enemyHpTooltipText.setText("0 / 0");

      this.drawBarPair(
        this.enemyHpBarBg,
        this.enemyHpBarFill,
        this.layout.barX,
        this.layout.hpBarY,
        this.layout.hpBarWidth,
        0,
        0x4caf50
      );

      this.drawBarPair(
        this.enemyGaugeBarBg,
        this.enemyGaugeBarFill,
        this.layout.barX,
        this.layout.gaugeBarY,
        this.layout.gaugeBarWidth,
        0,
        0x66ccff
      );

      return;
    }

    const enemy = battleState.enemy;
    const enemyHpRatio = (enemy?.health ?? 0) / Math.max(1, enemy?.maxHealth ?? 1);
    const enemyGaugeRatio = (enemy?.gauge ?? 0) / 100;

    this.enemyHpTooltipText.setText(`${enemy?.health ?? 0} / ${enemy?.maxHealth ?? 0}`);

    this.drawBarPair(
      this.enemyHpBarBg,
      this.enemyHpBarFill,
      this.layout.barX,
      this.layout.hpBarY,
      this.layout.hpBarWidth,
      enemyHpRatio,
      this.getHealthColor(enemyHpRatio)
    );

    this.drawBarPair(
      this.enemyGaugeBarBg,
      this.enemyGaugeBarFill,
      this.layout.barX,
      this.layout.gaugeBarY,
      this.layout.gaugeBarWidth,
      enemyGaugeRatio,
      0x66ccff
    );

    this.enemyHpBarHitArea.setPosition(
      this.layout.barX + this.layout.hpBarWidth / 2,
      this.layout.hpBarY + this.layout.barHeight / 2
    );
    this.enemyHpBarHitArea.setSize(
      this.layout.hpBarWidth,
      this.layout.barHeight
    );
  }

  hide() {
    this.container.setAlpha(0);
    this.scene.cursorManager.setState("default");
    this.hoverRectangle.setAlpha(0);
    this.enemyHpTooltipBg.setVisible(false);
    this.enemyHpTooltipText.setVisible(false);
    this.isHoveringHpBar = false;
    this.panelBg.disableInteractive();
    this.closeButton.disableInteractive();
    this.enemyHpBarHitArea.disableInteractive();
    this.isDragging = false;
  }

  show() {
    this.container.setAlpha(1);

    this.panelBg.setInteractive(
      new Phaser.Geom.Rectangle(
        -this.panelWidth / 2,
        -this.panelHeight / 2,
        this.panelWidth,
        this.panelHeight
      ),
      Phaser.Geom.Rectangle.Contains
    );

    this.closeButton.setInteractive(
      new Phaser.Geom.Rectangle(
        0,
        0,
        this.closeButton.displayWidth,
        this.closeButton.displayHeight
      ),
      Phaser.Geom.Rectangle.Contains
    );

    this.enemyHpBarHitArea.setInteractive({ useHandCursor: false });
  }

  update() {
    this.refreshBattleUI();
    this.updateHpTooltip();
  }
}