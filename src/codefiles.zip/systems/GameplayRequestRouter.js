import { ENEMY_DATA } from "../data/enemiesData.js";

export default class GameplayRequestRouter {
  constructor(eventBus, config = {}) {
    this.eventBus = eventBus;

    this.mapUI = config.mapUI ?? null;
    this.combatSystem = config.combatSystem ?? null;
    this.gatheringSystem = config.gatheringSystem ?? null;
    this.processingSystem = config.processingSystem ?? null;

    this.onBattleRequested = this.onBattleRequested.bind(this);
    this.onGatheringRequested = this.onGatheringRequested.bind(this);
    this.onProcessingRequested = this.onProcessingRequested.bind(this);
  }

  register() {
    this.eventBus.on("battle.requested", this.onBattleRequested);
    this.eventBus.on("gathering.requested", this.onGatheringRequested);
    this.eventBus.on("processing.requested", this.onProcessingRequested);
  }

  destroy() {
    this.eventBus.off("battle.requested", this.onBattleRequested);
    this.eventBus.off("gathering.requested", this.onGatheringRequested);
    this.eventBus.off("processing.requested", this.onProcessingRequested);
  }

  getNodeById(nodeId) {
    if (!this.mapUI?.nodes || !nodeId) {
      return null;
    }

    return this.mapUI.nodes.get(nodeId) ?? null;
  }

  onBattleRequested(event) {
    const { nodeId, nodeData, enemyId } = event.payload ?? {};

    if (!nodeId || !nodeData || !enemyId || !this.combatSystem) {
      return;
    }

    const enemyData = ENEMY_DATA[enemyId];
    if (!enemyData) {
      return;
    }

    const node = this.getNodeById(nodeId);

    this.combatSystem.startBattle({
      enemyId,
      enemyData,
      nodeData,
      node
    });
  }

  onGatheringRequested(event) {
    const { nodeId, nodeData } = event.payload ?? {};

    if (!nodeId || !nodeData || !this.gatheringSystem) {
      return;
    }

    const node = this.getNodeById(nodeId);

    this.gatheringSystem.startGathering(nodeData, node);
  }

  onProcessingRequested(event) {
    const { nodeId, nodeData } = event.payload ?? {};

    if (!nodeId || !nodeData || !this.processingSystem) {
      return;
    }

    const node = this.getNodeById(nodeId);

    this.processingSystem.openStation(nodeData, node);
  }
}