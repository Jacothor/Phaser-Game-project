import Phaser from "phaser";

export default class CombatSystem {
  constructor(scene, config = {}) {
    this.scene = scene;

    this.battlePanel = config.battlePanel ?? null;
    this.playerPanel = config.playerPanel ?? null;
    this.playerState = config.playerState ?? null;
    this.playerWorldState = config.playerWorldState ?? null;
    this.mapUI = config.mapUI ?? null;

    this.isBattleActive = false;
    this.currentBattle = null;

    this.GAUGE_MAX = 100;
    this.MIN_ACTION_TIME = 1;
    this.MAX_ACTION_TIME = 5;
    this.SPEED_CURVE_K = 20;

    this.BASE_HIT_CHANCE = 75;
    this.HIT_CHANCE_FACTOR = 0.5;
    this.MIN_HIT_CHANCE = 25;
    this.MAX_HIT_CHANCE = 95;

    this.DAMAGE_ATTACK_SCALAR = 0.2;
    this.DAMAGE_DEFENSE_K = 100;
  }

  startBattle({ enemyId, enemyData, nodeData = null, node = null }) {
    if (this.isBattleActive) {
      console.warn("CombatSystem: battle already active.");
      return false;
    }

    if (!this.playerState) {
      console.warn("CombatSystem: missing playerState.");
      return false;
    }

    if (!enemyId || !enemyData) {
      console.warn("CombatSystem: missing enemy data.");
      return false;
    }

    const playerStats = this.playerState.getStats();
    const enemyStats = this.buildEnemyStats(enemyData);

    this.currentBattle = {
      enemyId,
      enemyData,
      nodeData,
      node,
      startedAt: Date.now(),
      result: null,
      turnCount: 0,
      log: [],

      player: {
        id: "player",
        name: "Player",
        ...playerStats,
        gauge: 0,
        actionTime: this.getActionTimeSeconds(playerStats.speed),
        gaugeFillPerSecond: this.getGaugeFillPerSecond(playerStats.speed)
      },

      enemy: {
        id: enemyId,
        name: enemyData.name || enemyId,
        ...enemyStats,
        gauge: 0,
        actionTime: this.getActionTimeSeconds(enemyStats.speed),
        gaugeFillPerSecond: this.getGaugeFillPerSecond(enemyStats.speed)
      }
    };

    this.currentBattle.node?.pausePatrol?.();

    this.isBattleActive = true;

    if (this.mapUI && this.mapUI.setBattleLocked) {
      this.mapUI.setBattleLocked(true);
    }

    if (this.battlePanel) {
      this.battlePanel.setEnemy(enemyId);
      this.battlePanel.show();

      if (this.battlePanel.syncBattleState) {
        this.battlePanel.syncBattleState(this.currentBattle);
      }
    }

    if (this.playerPanel && this.playerPanel.enterBattleStance) {
      this.playerPanel.enterBattleStance();
    }

    if (this.playerPanel && this.playerPanel.syncBattleState) {
      this.playerPanel.syncBattleState(this.currentBattle);
    }

    this.addLogEntry(`Battle started against ${this.currentBattle.enemy.name}.`);

    console.log("Battle started:", this.currentBattle);
    return true;
  }

  buildEnemyStats(enemyData) {
    const maxHealth = enemyData.health ?? 1;

    return {
      health: maxHealth,
      maxHealth,
      attack: enemyData.attack ?? 1,
      defense: enemyData.defense ?? 0,
      speed: enemyData.speed ?? 1,
      accuracy: enemyData.accuracy ?? 1,
      evasion: enemyData.evasion ?? 1
    };
  }

  endBattle(result = "unknown") {
    if (!this.isBattleActive || !this.currentBattle) {
      return;
    }

    this.currentBattle.result = result;

    if (result === "player_win") {
      this.addLogEntry("You won the battle.");
    } else if (result === "player_lose") {
      this.addLogEntry("You were defeated.");
    } else {
      this.addLogEntry("The battle ended.");
    }

    if (this.battlePanel && this.battlePanel.syncBattleState) {
      this.battlePanel.syncBattleState(this.currentBattle);
    }

    console.log("Battle ended:", result, this.currentBattle);

    if (result === "player_win" && this.battlePanel) {
      const sprite = this.battlePanel.enemySprite;

      this.isBattleActive = false;

      if (sprite) {
        sprite.once("animationcomplete", () => {
          this.finishBattlePresentation();
        });

        this.battlePanel.playEnemyAnim("die");
        return;
      }

      this.finishBattlePresentation();
      return;
    }

    if (result === "player_lose") {
      if (this.playerPanel && this.playerPanel.playDeathAnim) {
        this.scene.time.delayedCall(500, () => {
          this.playerPanel.playDeathAnim();
        });
      }

      this.scene.time.delayedCall(1000, () => {
        this.finishBattlePresentation();
      });

      this.isBattleActive = false;
      return;
    }

    if (this.playerPanel && this.playerPanel.exitBattleStance) {
      this.playerPanel.exitBattleStance();
    }

    if (this.playerPanel && this.playerPanel.syncBattleState) {
      this.playerPanel.syncBattleState(null);
    }

    if (this.mapUI && this.mapUI.setBattleLocked) {
      this.mapUI.setBattleLocked(false);
    }

    this.isBattleActive = false;
    this.clearBattle();
  }

  clearBattle() {
    this.currentBattle = null;
  }

  update(delta) {
    if (!this.isBattleActive || !this.currentBattle) {
      return;
    }

    const deltaSeconds = delta / 1000;
    const { player, enemy } = this.currentBattle;

    this.syncPlayerFromState();
    this.refreshCombatantTiming(player);
    this.refreshCombatantTiming(enemy);

    this.fillGauge(player, deltaSeconds);
    this.fillGauge(enemy, deltaSeconds);

    if (this.battlePanel && this.battlePanel.syncBattleState) {
      this.battlePanel.syncBattleState(this.currentBattle);
    }

    if (this.playerPanel && this.playerPanel.syncBattleState) {
      this.playerPanel.syncBattleState(this.currentBattle);
    }

    while (player.gauge >= this.GAUGE_MAX && this.isBattleActive) {
      this.resolveReadyCombatant(player, enemy);

      if (!this.isBattleActive) {
        break;
      }
    }

    while (enemy.gauge >= this.GAUGE_MAX && this.isBattleActive) {
      this.resolveReadyCombatant(enemy, player);

      if (!this.isBattleActive) {
        break;
      }
    }
  }

  syncPlayerFromState() {
    if (!this.currentBattle || !this.playerState) {
      return;
    }

    const livePlayerStats = this.playerState.getStats();

    this.currentBattle.player.health = livePlayerStats.health;
    this.currentBattle.player.maxHealth = livePlayerStats.maxHealth;
    this.currentBattle.player.attack = livePlayerStats.attack;
    this.currentBattle.player.defense = livePlayerStats.defense;
    this.currentBattle.player.speed = livePlayerStats.speed;
    this.currentBattle.player.accuracy = livePlayerStats.accuracy;
    this.currentBattle.player.evasion = livePlayerStats.evasion;
  }

  refreshCombatantTiming(combatant) {
    combatant.actionTime = this.getActionTimeSeconds(combatant.speed);
    combatant.gaugeFillPerSecond = this.GAUGE_MAX / combatant.actionTime;
  }

  fillGauge(combatant, deltaSeconds) {
    combatant.gauge += combatant.gaugeFillPerSecond * deltaSeconds;

    const maxOverflow = this.GAUGE_MAX * 2;
    if (combatant.gauge > maxOverflow) {
      combatant.gauge = maxOverflow;
    }
  }

  resolveReadyCombatant(attacker, defender) {
    if (!this.isBattleActive || !this.currentBattle) {
      return;
    }

    if (attacker.health <= 0 || defender.health <= 0) {
      return;
    }

    attacker.gauge -= this.GAUGE_MAX;
    this.currentBattle.turnCount += 1;

    const attackResult = this.resolveBasicAttack(attacker, defender);
    this.showCombatImpact(attackResult);

    console.log("Attack resolved:", attackResult);

    if (attacker.id === "player") {
      if (this.playerPanel && this.playerPanel.playAttackAnim) {
        this.playerPanel.playAttackAnim();
      }
    } else {
      if (this.battlePanel) {
        this.battlePanel.playEnemyAnim("attack");
      }
    }

    if (this.battlePanel && this.battlePanel.syncBattleState) {
      this.battlePanel.syncBattleState(this.currentBattle);
    }

    if (this.playerPanel && this.playerPanel.syncBattleState) {
      this.playerPanel.syncBattleState(this.currentBattle);
    }

    this.checkBattleEnd();
  }

  resolveBasicAttack(attacker, defender) {
    const hitChance = this.getHitChancePercent(attacker, defender);
    const hitRoll = Phaser.Math.Between(1, 100);
    const hit = hitRoll <= hitChance;

    if (!hit) {
      const missMessage = `${attacker.name} attacks ${defender.name} but misses.`;
      this.addLogEntry(missMessage);

      if (defender.id === "player") {
        if (this.playerPanel && this.playerPanel.playGuardAnim) {
          this.playerPanel.playGuardAnim();
        }
      }

      return {
        type: "attack",
        attackerId: attacker.id,
        defenderId: defender.id,
        hit: false,
        hitRoll,
        hitChance,
        damage: 0,
        defenderHealth: defender.health,
        defenderMaxHealth: defender.maxHealth
      };
    }

    const damage = this.calculateDamage(attacker, defender);

    if (defender.id === "player") {
      this.playerState.takeDamage(damage);
      this.syncPlayerFromState();

      if (this.currentBattle.player.health > 0) {
        if (this.playerPanel && this.playerPanel.playDamageAnim) {
          this.playerPanel.playDamageAnim();
        }
      }
    } else {
      defender.health = Math.max(0, defender.health - damage);
    }

    const hitMessage = `${attacker.name} hits ${defender.name} for ${damage} damage.`;
    this.addLogEntry(hitMessage);

    return {
      type: "attack",
      attackerId: attacker.id,
      defenderId: defender.id,
      hit: true,
      hitRoll,
      hitChance,
      damage,
      defenderHealth: defender.health,
      defenderMaxHealth: defender.maxHealth
    };
  }

  getHitChancePercent(attacker, defender) {
    const accuracy = attacker.accuracy ?? 0;
    const evasion = defender.evasion ?? 0;

    const hitChance =
      this.BASE_HIT_CHANCE + (accuracy - evasion) * this.HIT_CHANCE_FACTOR;

    return Phaser.Math.Clamp(
      Math.round(hitChance),
      this.MIN_HIT_CHANCE,
      this.MAX_HIT_CHANCE
    );
  }

  calculateDamage(attacker, defender) {
    const attack = Math.max(0, attacker.attack ?? 0);
    const defense = Math.max(0, defender.defense ?? 0);

    const scaledAttack = attack * this.DAMAGE_ATTACK_SCALAR;
    const mitigation = this.DAMAGE_DEFENSE_K / (this.DAMAGE_DEFENSE_K + defense);

    const rawDamage = 1 + scaledAttack * mitigation;
    const damage = Math.floor(rawDamage);

    return Math.max(1, damage);
  }

  checkBattleEnd() {
    if (!this.isBattleActive || !this.currentBattle) {
      return;
    }

    const { player, enemy } = this.currentBattle;

    if (enemy.health <= 0) {
      this.endBattle("player_win");
      return;
    }

    if (player.health <= 0) {
      this.endBattle("player_lose");
    }
  }

  showCombatImpact(attackResult) {
    if (!attackResult) {
      return;
    }

    const targetPanel =
      attackResult.defenderId === "player"
        ? this.playerPanel
        : this.battlePanel;

    if (!targetPanel || !targetPanel.showDamageEffect) return;

    targetPanel.showDamageEffect({
      hit: attackResult.hit,
      damage: attackResult.damage
    });
  }

  finishBattlePresentation() {
    if (!this.currentBattle) {
      return;
    }

    const result = this.currentBattle.result;
    const nodeData = this.currentBattle.nodeData;
    const enemyData = this.currentBattle.enemyData;

    if (result === "player_win" && nodeData && this.playerWorldState) {
      const nodeId = nodeData.id;
      const respawnTime = enemyData?.respawn ?? 10000;
      const returnState = nodeData.defaultState ?? "default";

      this.playerWorldState.setNodeState(nodeId, "hidden");

      if (this.mapUI && this.mapUI.refreshFromWorldState) {
        this.mapUI.refreshFromWorldState();
      }

      this.scene.time.delayedCall(respawnTime, () => {
        if (!this.playerWorldState) return;

        this.playerWorldState.setNodeState(nodeId, returnState);

        if (this.mapUI && this.mapUI.refreshFromWorldState) {
          this.mapUI.refreshFromWorldState();
        }

        const respawnedNode = this.mapUI?.getNodeById(nodeId);
        if (respawnedNode && respawnedNode.resumePatrol) {
            respawnedNode.resumePatrol();
        }
      });
    }

    if (this.battlePanel) {
      this.battlePanel.hide();
      this.scene.lootSystem.generateLootFromEnemy(this.currentBattle.enemyId);
      this.scene.lootPanel.show();
      this.scene.lootPanel.refresh();
    }

    if (this.playerPanel) {
      if (this.playerPanel.exitBattleStance) {
        this.playerPanel.exitBattleStance();
      }

      if (this.playerPanel.syncBattleState) {
        this.playerPanel.syncBattleState(null);
      }
    }

    if (this.mapUI && this.mapUI.setBattleLocked) {
      this.mapUI.setBattleLocked(false);
    }

    this.clearBattle();
  }

  addLogEntry(message) {
    if (!this.currentBattle) {
      return;
    }

    this.currentBattle.log.push(message);

    if (this.currentBattle.log.length > 20) {
      this.currentBattle.log.shift();
    }
  }

  getActionTimeSeconds(effectiveSpeed) {
    const safeSpeed = Math.max(0, effectiveSpeed ?? 0);

    const actionTime =
      this.MAX_ACTION_TIME -
      (safeSpeed / (safeSpeed + this.SPEED_CURVE_K)) *
        (this.MAX_ACTION_TIME - this.MIN_ACTION_TIME);

    return Phaser.Math.Clamp(
      actionTime,
      this.MIN_ACTION_TIME,
      this.MAX_ACTION_TIME
    );
  }

  getGaugeFillPerSecond(effectiveSpeed) {
    const actionTime = this.getActionTimeSeconds(effectiveSpeed);
    return this.GAUGE_MAX / actionTime;
  }

  getBattleState() {
    return this.currentBattle;
  }

  hasActiveBattle() {
    return this.isBattleActive;
  }
}