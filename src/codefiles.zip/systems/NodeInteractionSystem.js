export default class NodeInteractionSystem {
  constructor(eventBus) {
    this.eventBus = eventBus;

    this.handlers = {
      enemy: this.handleEnemyNode.bind(this),
      resource: this.handleResourceNode.bind(this),
      station: this.handleStationNode.bind(this)
    };

    this.onNodeClicked = this.onNodeClicked.bind(this);
  }

  register() {
    this.eventBus.on("node.clicked", this.onNodeClicked);
  }

  destroy() {
    this.eventBus.off("node.clicked", this.onNodeClicked);
  }

  onNodeClicked(event) {
    const { nodeId, nodeData } = event.payload ?? {};

    if (!nodeId || !nodeData) {
      return;
    }

    const handler = this.handlers[nodeData.type];
    if (!handler) {
      return;
    }

    handler(nodeData);
  }

  handleEnemyNode(nodeData) {
    this.eventBus.emit("battle.requested", {
      nodeId: nodeData.id,
      nodeData,
      enemyId: nodeData.enemyId ?? nodeData.id
    }, "system");
  }

  handleResourceNode(nodeData) {
    if (nodeData.subType !== "harvest") {
      return;
    }

    this.eventBus.emit("gathering.requested", {
      nodeId: nodeData.id,
      nodeData,
      gatherNodeDefId: nodeData.gatherNodeDefId ?? null
    }, "system");
    console.log(nodeData);
  }

  handleStationNode(nodeData) {
    this.eventBus.emit("processing.requested", {
      nodeId: nodeData.id,
      nodeData,
      stationDefId: nodeData.stationDefId ?? null
    }, "system");
  }
}