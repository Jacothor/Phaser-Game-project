// src/systems/GatheringSystem.js

import { GATHERING_NODE_DATA, getRandomNodeCapacity } from "../data/gatheringData.js";

export default class GatheringSystem {
  constructor(scene, config = {}) {
    this.scene = scene;
    this.playerState = config.playerState ?? null;
    this.playerWorldState = config.playerWorldState ?? null;
    this.inventorySystem = config.inventorySystem ?? null;
    this.activitySystem = config.activitySystem ?? null;
    this.mapUI = config.mapUI ?? null;
    this.gatherProgressUI = config.gatherProgressUI ?? null;
  }

  startGathering(nodeData, node = null) {
    if (!this.playerState || !this.playerWorldState || !this.inventorySystem || !this.activitySystem) {
      console.warn("GatheringSystem: missing dependencies.");
      return false;
    }

    if (!nodeData || nodeData.type !== "resource" || nodeData.subType !== "harvest") {
      return false;
    }

    const gatherNodeDefId = nodeData.gatherNodeDefId ?? null;
    if (!gatherNodeDefId) {
      console.warn(`GatheringSystem: node "${nodeData.id}" missing gatherNodeDefId.`);
      return false;
    }

    const gatherDef = GATHERING_NODE_DATA[gatherNodeDefId];
    if (!gatherDef) {
      console.warn(`GatheringSystem: gather def "${gatherNodeDefId}" not found.`);
      return false;
    }

    if (!this.canGatherNode(nodeData, gatherDef)) {
      return false;
    }

    if (this.activitySystem.hasActiveActivity()) {
      const active = this.activitySystem.getActiveActivity();

      if (active?.type === "gathering" && active.nodeId === nodeData.id) {
        return true;
      }

      this.cancelGathering("node_changed");
    }

    this.ensureNodeCapacity(nodeData, gatherDef);

    const remaining = this.getNodeRemaining(nodeData.id);
    if (remaining <= 0) {
      this.depleteNode(nodeData, gatherDef);
      return false;
    }

    return this.startGatherCycle(nodeData, gatherDef, node);
  }

  canGatherNode(nodeData, gatherDef) {
    const nodeState = this.playerWorldState.getNodeState(
      nodeData.id,
      nodeData.defaultState ?? "default"
    );

    if (nodeState === "hidden") {
      return false;
    }

    if (!this.playerState.hasSkillLevel(gatherDef.skillId, gatherDef.levelRequired)) {
      return false;
    }

    if (!this.inventorySystem.canAddItem(gatherDef.outputItemId, 1)) {
      return false;
    }

    return true;
  }

  startGatherCycle(nodeData, gatherDef, node = null) {
    const started = this.activitySystem.startActivity({
      id: `gather_${nodeData.id}`,
      type: "gathering",
      label: gatherDef.name,
      durationMs: gatherDef.cycleDurationMs,
      nodeId: nodeData.id,
      nodeData,
      context: {
        gatherNodeDefId: gatherDef.id,
        skillId: gatherDef.skillId,
        outputItemId: gatherDef.outputItemId,
        xpPerGather: gatherDef.xpPerGather
      },
      onStart: (activity) => {
        this.setActiveGatherState(nodeData, gatherDef, activity);

        if (node?.setSelected) {
          node.setSelected(true);
        }

        if (this.gatherProgressUI?.showForNode) {
          this.gatherProgressUI.showForNode(node, {
            label: gatherDef.name
          });
        }
      },
      onTick: (activity) => {
        this.syncGatherProgress(activity);
      },
      onComplete: (activity) => {
        this.completeGatherCycle(activity, node);
      },
      onCancel: () => {
        this.clearActiveGatherState(nodeData.id);

        if (this.gatherProgressUI?.hide) {
          this.gatherProgressUI.hide();
        }
      }
    });

    return started;
  }

  completeGatherCycle(activity, node = null) {
    const nodeData = activity.nodeData;
    const gatherDef = GATHERING_NODE_DATA[activity.context.gatherNodeDefId];

    if (!nodeData || !gatherDef) {
      return;
    }

    if (!this.canGatherNode(nodeData, gatherDef)) {
      this.clearActiveGatherState(nodeData.id);

      if (this.gatherProgressUI?.hide) {
        this.gatherProgressUI.hide();
      }
      return;
    }

    const addSuccess = this.inventorySystem.addItem(gatherDef.outputItemId, 1);

    if (!addSuccess) {
      this.clearActiveGatherState(nodeData.id);

      if (this.gatherProgressUI?.hide) {
        this.gatherProgressUI.hide();
      }
      return;
    }

    this.playerState.addSkillExp(gatherDef.skillId, gatherDef.xpPerGather);

    const remainingAfterGather = this.consumeNodeCharge(nodeData.id);

    this.scene.inventoryPanel?.refresh?.();

    if (remainingAfterGather <= 0) {
      this.depleteNode(nodeData, gatherDef);
      return;
    }

    this.startGatherCycle(nodeData, gatherDef, node);
  }

  cancelGathering(reason = "cancelled") {
    if (!this.activitySystem.hasActiveActivity()) {
      return false;
    }

    const active = this.activitySystem.getActiveActivity();
    if (active?.type !== "gathering") {
      return false;
    }

    return this.activitySystem.cancelActivity(reason);
  }

  update() {
    const active = this.activitySystem.getActiveActivity();

    if (!active || active.type !== "gathering") {
      return;
    }

    if (this.gatherProgressUI?.setProgress) {
      this.gatherProgressUI.setProgress(active.progress);
    }
  }

  ensureNodeCapacity(nodeData, gatherDef) {
    const nodeEntry = this.playerWorldState.getNodeData(nodeData.id, {}) ?? {};
    const currentRemaining = nodeEntry.remainingCharges;

    if (typeof currentRemaining === "number" && currentRemaining > 0) {
      return currentRemaining;
    }

    const rolledCapacity = getRandomNodeCapacity(gatherDef);

    this.playerWorldState.setNodeData(nodeData.id, {
      gatherNodeDefId: gatherDef.id,
      remainingCharges: rolledCapacity,
      maxCharges: rolledCapacity,
      depleted: false
    });

    return rolledCapacity;
  }

  getNodeRemaining(nodeId) {
    const nodeData = this.playerWorldState.getNodeData(nodeId, {});
    return Math.max(0, nodeData?.remainingCharges ?? 0);
  }

  consumeNodeCharge(nodeId) {
    const nodeData = this.playerWorldState.getNodeData(nodeId, {}) ?? {};
    const current = Math.max(0, nodeData.remainingCharges ?? 0);
    const next = Math.max(0, current - 1);

    this.playerWorldState.setNodeData(nodeId, {
      remainingCharges: next
    });

    return next;
  }

  depleteNode(nodeData, gatherDef) {
    this.clearActiveGatherState(nodeData.id);

    this.playerWorldState.setNodeState(
      nodeData.id,
      nodeData.worldRules?.onGatherState ?? "hidden",
      gatherDef.respawnTimeMs,
      {
        gatherNodeDefId: gatherDef.id,
        remainingCharges: 0,
        maxCharges: 0,
        depleted: true
      }
    );

    if (this.mapUI?.refreshFromWorldState) {
      this.mapUI.refreshFromWorldState();
    }

    if (this.gatherProgressUI?.hide) {
      this.gatherProgressUI.hide();
    }
  }

  setActiveGatherState(nodeData, gatherDef, activity) {
    this.playerWorldState.setNodeData(nodeData.id, {
      gatherNodeDefId: gatherDef.id,
      activeActivityType: "gathering",
      activeProgress: activity.progress ?? 0
    });
  }

  syncGatherProgress(activity) {
    if (!activity?.nodeId) {
      return;
    }

    this.playerWorldState.setNodeData(activity.nodeId, {
      activeProgress: activity.progress ?? 0
    });

    if (this.gatherProgressUI?.setProgress) {
      this.gatherProgressUI.setProgress(activity.progress ?? 0);
    }
  }

  clearActiveGatherState(nodeId) {
    const data = this.playerWorldState.getNodeData(nodeId, {}) ?? {};

    delete data.activeActivityType;
    delete data.activeProgress;

    this.playerWorldState.setNodeData(nodeId, data);
  }

  isGatheringNode(nodeId) {
    const active = this.activitySystem.getActiveActivity();
    return active?.type === "gathering" && active.nodeId === nodeId;
  }
}