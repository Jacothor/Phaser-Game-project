export default class EventBus {
  constructor() {
    this.queue = [];
    this.nextQueue = [];
    this.listeners = new Map();
  }

  emit(type, payload = {}, source = "client") {
    this.queue.push({
      type,
      payload,
      source
    });
  }

  on(type, handler) {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, new Set());
    }
    this.listeners.get(type).add(handler);
  }

  off(type, handler) {
    const set = this.listeners.get(type);
    if (!set) return;
    set.delete(handler);
  }

  process() {
    while (this.queue.length > 0) {
      const event = this.queue.shift();
      const handlers = this.listeners.get(event.type);

      if (!handlers) continue;

      for (const handler of handlers) {
        handler(event);
      }
    }

    // swap queues (for future safety if needed)
    if (this.nextQueue.length > 0) {
      this.queue = this.nextQueue;
      this.nextQueue = [];
    }
  }
}