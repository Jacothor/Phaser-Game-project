export const TEST_MAP_DATA = {
  id: "test_map",
  name: "",
  nodes: [
    {
      id: "wolves_01",
      name: "Wolf",
      enemyId:"gray_wolf",
      level: 1,
      iconSheet: "RPG",
      iconFrame: 184,
      type: "enemy",
      tier: 1,
      mapX: 140,
      mapY: 120,
      defaultState: "alive",

      patrolRadius: 20,
      patrolSpeed: 1200,

      worldRules: {
        onWinState: "hidden",
        returnState: "alive",
        returnTime: 10000
      }
    },

        {
      id: "wolves_02",
      name: "Wolf",
      enemyId:"gray_wolf",
      level: 1,
      iconSheet: "RPG",
      iconFrame: 184,
      type: "enemy",
      tier: 1,
      mapX: 160,
      mapY: 100,
      defaultState: "alive",

      patrolRadius: 20,
      patrolSpeed: 1200,

      worldRules: {
        onWinState: "hidden",
        returnState: "alive",
        returnTime: 10000
      }
    },

        {
      id: "wolves_03",
      name: "Wolf",
      enemyId:"gray_wolf",
      level: 1,
      iconSheet: "RPG",
      iconFrame: 184,
      type: "enemy",
      tier: 1,
      mapX: 80,
      mapY: 80,
      defaultState: "alive",

      patrolRadius: 20,
      patrolSpeed: 1200,

      worldRules: {
        onWinState: "hidden",
        returnState: "alive",
        returnTime: 10000
      }
    },

    {
      id: "bandits_01",
      name: "Bandits",
      label: "Bandits",
      iconSheet: "RPG",
      iconFrame: 190,
      type: "enemy",
      subType: "group",
      tier: 2,
      mapX: 220,
      mapY: 120,
      defaultState: "alive",

      worldRules: {
        onWinState: "hidden",
        returnState: "alive",
        returnTime: 20000
      }
    },

    {
      id: "tree_01",
      name: "Oak Tree",
      label: "Tree",
      iconSheet: "TOOLS",
      iconFrame: 48,
      type: "resource",
      subType: "harvest",
      tier: 1,
      mapX: 300,
      mapY: 180,
      defaultState: "ready",

      worldRules: {
        onGatherState: "hidden",
        returnState: "ready",
        returnTime: 15000
      }
    },

    {
      id: "iron_vein_01",
      name: "Iron Vein",
      label: "Iron",
      iconSheet: "TOOLS",
      iconFrame: 52,
      type: "resource",
      subType: "harvest",
      gatherNodeDefId: "iron_vein",
      tier: 2,
      rarity: "uncommon",
      mapX: 380,
      mapY: 210,
      defaultState: "ready",

      worldRules: {
        onGatherState: "hidden",
        returnState: "ready",
        returnTime: 45000
      }
  },

    {
      id: "gold_vein_01",
      name: "Gold Vein",
      label: "Gold",
      iconSheet: "TOOLS",
      iconFrame: 53,
      type: "resource",
      subType: "harvest",
      tier: 4,
      rarity: "rare",
      mapX: 430,
      mapY: 250,
      defaultState: "ready",

      worldRules: {
        onGatherState: "hidden",
        returnState: "ready",
        returnTime: 120000,
        limitedCount: 1
      }
    },

    {
      id: "chest_01",
      name: "Old Chest",
      label: "Chest",
      iconSheet: "TOOLS",
      iconFrame: 84,
      type: "treasure",
      subType: "loot",
      tier: 1,
      mapX: 470,
      mapY: 140,
      defaultState: "closed",

      worldRules: {
        onLootState: "hidden",
        returnState: "closed",
        returnTime: 60000
      }
    },

    {
  id: "smithing_anvil_01",
  name: "Smithing Anvil",
  label: "Anvil",
  iconSheet: "TOOLS",
  iconFrame: 10,
  type: "station",
  stationDefId: "smithing_anvil",
  mapX: 500,
  mapY: 260,
  defaultState: "ready"
},

{
  id: "whittling_bench_01",
  name: "Whittling Bench",
  label: "Bench",
  iconSheet: "TOOLS",
  iconFrame: 11,
  type: "station",
  stationDefId: "whittling_bench",
  mapX: 540,
  mapY: 300,
  defaultState: "ready"
}
  ]
};